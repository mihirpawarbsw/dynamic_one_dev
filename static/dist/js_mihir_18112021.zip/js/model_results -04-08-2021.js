$(document).ready(function(){
	var myChart1; 
	var myChart;
// // alert('yes!!');
// flag=window.localStorage.getItem('flag');
// if (flag==0) {
//    window.location.replace("https://forecasting.azurewebsites.net/");
//    // window.location.replace("http://127.0.0.1:8000");
// }
showPreloader();
var csrfmiddlewaretoken=csrftoken;

   setTimeout(function () {
			// var social_media_type = $("#social_media_type").val();
			var analyzeInput = $("#analyzeInput").val();
			var historic_data = $("#historic_data").val();
			var model_type = "Holt_Winter_Model";
			// alert(historic_data);
			var checkData2 = "csrfmiddlewaretoken=" + csrfmiddlewaretoken+"&analyzeInput=" + analyzeInput+"&model_type=" + model_type;
			respdata2 = autoresponse("model_results", checkData2);
			if (respdata2.status  == 200)
			// if (respdata2.status  == 200)
			{
			    // hidePreloader();
				model_summary_div_table1(respdata2);
				EvaluationMetrics_div_table1(respdata2);
				arima_actual_fitted_chart(respdata2);
				forecast_fitted_chart(respdata2);
			// alert('yes');
			}
			else
			{
				// alert('no holt winter model');
				$('#HOLT_WINTER_NA_ID_id').css("display","block")//#MODIFICATION DONE BY PRANIT ON 25-05-2021
				hidePreloader();//#MODIFICATION DONE BY PRANIT ON 25-05-2021
			}

		}, 100);



$("#analyzeInput_btn").click(function(){
  // alert("The paragraph was clicked.");
  
    showPreloader();
    setTimeout(function () {
			var analyzeInput = $("#analyzeInput").val();
			// alert(analyzeInput);
			model_type = $("#nav-tab a.active").attr('id');
			var checkData2 = "csrfmiddlewaretoken=" + csrfmiddlewaretoken+"&analyzeInput=" + analyzeInput+"&model_type=" + model_type;
			respdata2 = autoresponse("model_results", checkData2);
			if (respdata2.status  == 200)
			{

			model_summary_div_table1(respdata2);
			EvaluationMetrics_div_table1(respdata2);
			arima_actual_fitted_chart(respdata2);
			forecast_fitted_chart(respdata2);

			// alert('yes');
			}
			else
			{
			alert('Something went wrong');
			}

		}, 100);


});

$("#ARIMA_Model").click(function(){
    // alert("nav-ARIMA-tab");

    showPreloader();
    setTimeout(function () {
			var analyzeInput = $("#analyzeInput").val();
			model_type = $("#nav-tab a.active").attr('id');
			var checkData2 = "csrfmiddlewaretoken=" + csrfmiddlewaretoken+"&analyzeInput=" + analyzeInput+"&model_type=" + model_type;
			respdata2 = autoresponse("model_results", checkData2);
			var myJSON = JSON.stringify(respdata2);
			// alert('wwwwwwwwwwwwwww');
			console.log('ARIMA_Model_respdata2============',typeof(respdata2));
			if (respdata2.status  == 200)
			{

			model_summary_div_table1(respdata2);
			EvaluationMetrics_div_table1(respdata2);
			arima_actual_fitted_chart(respdata2);
			forecast_fitted_chart(respdata2);

			// alert('yes');
			}
			else
			{
			// alert('no');
			$('#ARIMA_NA_ID_id').css("display","block")//#MODIFICATION DONE BY PRANIT ON 25-05-2021
		    hidePreloader();//#MODIFICATION DONE BY PRANIT ON 25-05-2021

			}

		}, 100);


});

$("#Holt_Winter_Model").click(function(){
    // alert("nav-ARIMA-tab");

    showPreloader();
    setTimeout(function () {
			var analyzeInput = $("#analyzeInput").val();
			model_type = $("#nav-tab a.active").attr('id');
			var checkData2 = "csrfmiddlewaretoken=" + csrfmiddlewaretoken+"&analyzeInput=" + analyzeInput+"&model_type=" + model_type;
			respdata2 = autoresponse("model_results", checkData2);
			if (respdata2.status  == 200)
			{

			model_summary_div_table1(respdata2);
			EvaluationMetrics_div_table1(respdata2);
			arima_actual_fitted_chart(respdata2);
			forecast_fitted_chart(respdata2);

			// alert('yes');
			}
			else
			{
			// alert('no');
			$('#HOLT_WINTER_NA_ID_id').css("display","block")//#MODIFICATION DONE BY PRANIT ON 25-05-2021
		    hidePreloader();//#MODIFICATION DONE BY PRANIT ON 25-05-2021
			}

		}, 100);


});

$("#ALL_MODEL_SUMMARY").click(function(){
    // alert("ALL_MODEL_SUMMARY");

    showPreloader();
    setTimeout(function () {
			var analyzeInput = $("#analyzeInput").val();
			model_type = $("#nav-tab a.active").attr('id');
			// alert(model_type)
			// alert(analyzeInput)
			var checkData2 = "csrfmiddlewaretoken=" + csrfmiddlewaretoken+"&analyzeInput=" + analyzeInput+"&model_type=" + model_type;
			respdata2 = autoresponse("all_model_summary", checkData2);
			if (respdata2.status  == 200)
			{
			// model_summary_div_table1(respdata2);
			// EvaluationMetrics_div_table1(respdata2);
			// arima_actual_fitted_chart(respdata2);
			ALL_MODEL_SUMMARY_table(respdata2);
			hidePreloader();
			// alert('yes');
			}
			else
			{
			$('#ALL_MODEL_SUMMARY_NA_ID_id').css("display","block")//#MODIFICATION DONE BY PRANIT ON 25-05-2021
		    hidePreloader();//#MODIFICATION DONE BY PRANIT ON 25-05-2021
			}

		}, 100);


});

function ALL_MODEL_SUMMARY_table(displayRecords) {
// alert('okay');
$('#Arima_mape').html((displayRecords.arima_mape_resp).toFixed(4));
$('#holt_winter_mape').html((displayRecords.holt_winter_mape_resp).toFixed(4));
$('#ucm_mape').html(displayRecords.ucm_mape_resp);
$('#Bayesia_mape').html(displayRecords.bayesia_mape_resp);
$('#Sarima_mape').html(displayRecords.sarima_mape_resp);
}

function model_summary_div_table1(displayRecords) {
	var html=i= '';
	
	
    $("#forecast_line_img_div img:last-child").remove();
    $("#actual_fitted_img_div img:last-child").remove();
    $("#arima_forecast_line_img_div img:last-child").remove();
    $("#arima_actual_fitted_img_div img:last-child").remove();
	html +='<table class="table table-striped table-responsive-sm">';
	html +='<thead>';
	html +='<tr class="table-font-hd">';
	html +='<th scope="col" colspan="4" class="px-1">Model Summary</th>';
	html +='</tr>';
	html +='</thead>';
	html +=' <tbody>';
	// for (var i = 0;i<7; i++) {
		html +='<tr>';
	
		$.each(displayRecords.Data1.table1, function (k1, value1) {
            // console.log('ssssssssssss',value1);
			html +='<td class="text-center">'+value1.Dep+'</td>';
			html +='<td class="text-center">'+value1.Sales+'</td>';
			html +='<td class="text-center">'+value1.Observations+'</td>';
			html +='<td class="text-center">'+value1.val+'</td>';
        html +='</tr>';
		});

	html +='</tbody>';
	html +='</table>';
    
        $("#forecast_line_img_div").append("<img src='/static/images/forecast_line/"+displayRecords.Data1.forecast_line_img+".jpg' class='img-fluid'  /> ");
        $("#actual_fitted_img_div").append("<img src='/static/images/actual_fitted/"+displayRecords.Data1.actual_fitted_img+".jpg' class='img-fluid'  /> ");
        $("#arima_forecast_line_img_div").append("<img src='/static/images/forecast_line/"+displayRecords.Data1.forecast_line_img+".jpg' class='img-fluid'  /> ");
        $("#arima_actual_fitted_img_div").append("<img src='/static/images/actual_fitted/"+displayRecords.Data1.actual_fitted_img+".jpg' class='img-fluid'  /> ");

        model_type = $("#nav-tab a.active").attr('id');
        if (model_type=='Holt_Winter_Model') {
        	$('#model_summary_div_table1').html(html);
        	hidePreloader();
        }
        else{
        	$('#Arima_model_summary_div_table1').html(html);
        	hidePreloader();
        }
		// $('#model_summary_div_table1').html(html);
		//  hidePreloader();
  }


function EvaluationMetrics_div_table1(displayRecords) {
	var html=i= '';
	html +='<table class="table table-striped table-responsive-sm">';
	html +='<thead>';
	html +='<tr class="table-font-hd">';
	html +='<th scope="col" colspan="4" class="px-1">Evaluation Metrics</th>';
	html +='</tr>';
	html +='</thead>';
	html +='<tbody>';
	html +='<tr>';
	html +='<td class="text-center">mape: </td>';
	html +='<td class="text-center">me: </td>';
	html +='<td class="text-center">mae: </td>';
	html +='<td class="text-center">mpe: </td>';
	html +='<td class="text-center">rsme: </td>';
	html +='<td class="text-center">corr:</td>';
	html +='<td class="text-center">minmax:</td>';
	html +='</tr>';
	html +='<tr>';
	$.each(displayRecords.Data1.table2, function (k1, value1) {
      
        html +='<td class="text-center">'+value1.toFixed(4)+'</td>';

	});	
	html +='</tr>';
	html +='</tbody>';
	html +='</table>';

	model_type = $("#nav-tab a.active").attr('id');
    if (model_type=='Holt_Winter_Model') {
    	$('#EvaluationMetrics_div_table1').html(html);
    	hidePreloader();
    }
    else{
    	$('#Arima_EvaluationMetrics_div_table1').html(html);
    	hidePreloader();
    }

	// $('#EvaluationMetrics_div_table1').html(html);
	//  hidePreloader();
  }


var myChart1;  
function arima_actual_fitted_chart(resp){
	if (myChart1) {
        myChart1.destroy();
    }
 var label = [],dataset_red=[];dataset_blue=[];
	model_type = $("#nav-tab a.active").attr('id');
	// alert(model_type);
	if (model_type=='Holt_Winter_Model') {
		var ctx = document.getElementById("holt_winter_actual_fitted_line_chart1").getContext('2d');
	}
	else{
       var ctx = document.getElementById("arima_actual_fitted_line_chart2").getContext('2d');
	}
	

	// console.log('dataset_blue',dataset_blue);
	// console.log('dataset_red',dataset_red);
	// console.log('label',label);
	// console.log('totalRecords',(totalRecords/ 12));
	$.each(resp.Data1.pred_actual_dict.data_blue_line, function(key, value) {
           var getMonth_resp=value.Month;
			var d = new Date(getMonth_resp);
			var n = d.getMonth();
			var y = d.getFullYear();
			getMonth_name=get_month_name(n);
			dataset_blue.push(value.Sales);
			label.push(getMonth_name+'-'+y);
			
	});
	$.each(resp.Data1.pred_actual_dict.data_red_line, function(key, value) {
			dataset_red.push(value.Sales);
	});
	// console.log('dataset_blue',dataset_blue);
	// console.log('dataset_blue',dataset_red);

	
	if(model_type=="ARIMA_Model"){
		// dataset_blue.shift();
		// dataset_red.shift();
		first_dataset_blue=dataset_blue[0]
		let replacedItem = dataset_red.splice(dataset_red.indexOf(0), 1, first_dataset_blue)

	}
	// console.log('dataset_blue remove',dataset_blue);
	console.log('dataset_red remove',dataset_red);
	var totalRecords = Object.keys(resp.Data1.pred_actual_dict.data_blue_line).length;
	  
	  myChart1 = new Chart(ctx, {
	  type: 'line',
	  data: {
		   
		    labels: label,
		    datasets: [
		    {
		      label: '# Actual Line',
		      data: dataset_blue,
		      // backgroundColor: 'rgba(255, 99, 132, 0.2)',
		      borderColor: 'blue',
		      borderWidth: 2,
		      fill: false
		    },
		    {
		      label: '# Fitted Line',
		      data: dataset_red,
		      // backgroundColor: 'red',
		      borderColor: 'red',
		      borderWidth: 2,
		      fill: false
		    }
		    ]
		  },
		  options: {
		    scales: {
		      yAxes: [{
		        ticks: {
		          beginAtZero: false,          
		          // stepSize: 100, // this worked as expected
		          // min:3000000,
		          // max:1900          
		        }
		      }],
		      xAxes: [{
		        ticks: {
		          maxTicksLimit: (totalRecords/ 12),
		           maxRotation:-120
		          // maxTicksLimit: 5
		        }
		      }]
		    }
		  }
		});


}
  
var myChart;
function forecast_fitted_chart(resp){
	if (myChart) {
        myChart.destroy();
    }
 var label = [];dataset_red=[];dataset_blue=[];label_red = [];color_array=[];
	model_type = $("#nav-tab a.active").attr('id');

	if (model_type=='Holt_Winter_Model') {
		var ctx = document.getElementById("holt_winter_forecast_line_chart").getContext('2d');
	}
	else{
       var ctx = document.getElementById("arima_forecast_line_chart").getContext('2d');
	}
	var len_color_blue = Object.keys(resp.Data1.forecast_actual_dict.data_blue_line).length;
	var len_color_red = Object.keys(resp.Data1.forecast_actual_dict.data_red_line).length;


	for (let j = 0; j < len_color_blue; j++) {
        color_name_blue='blue';
        color_array.push(color_name_blue);
    }
    for (let j = 0; j < len_color_red; j++) {
        color_name_red='red';
        color_array.push(color_name_red);
    }



	// console.log('color_array',color_array);
	// console.log('dataset_red',dataset_red);
	// console.log('label',label);
	// console.log('totalRecords',(totalRecords/ 12));
	$.each(resp.Data1.forecast_actual_dict.data_blue_line, function(key, value) {
           var getMonth_resp=value.Month;
			var d = new Date(getMonth_resp);
			var n = d.getMonth();
			var y = d.getFullYear();
			getMonth_name=get_month_name(n);
			dataset_blue.push(value.Sales);
			label.push(getMonth_name+'-'+y);
			
	});

	$.each(resp.Data1.forecast_actual_dict.data_red_line, function(key1, value1) {
			var red_getMonth_resp=value1.Month;
			var red_d = new Date(red_getMonth_resp);
			var red_n = red_d.getMonth();
			var red_y = red_d.getFullYear();
			var red_getMonth_name=get_month_name(red_n);
			dataset_red.push(value1.Sales);
			label_red.push(red_getMonth_name+'-'+red_y);
	});

	$.each(dataset_red, function(key2, value2) {
			dataset_blue.push(value2);
	});
	$.each(label_red, function(key3, value3) {
			label.push(value3);
	});
 //    console.log('dataset_blue',dataset_blue);
	// console.log('dataset_blue',label);
   // console.log('dataset_red',dataset_red);
   // 	console.log('label_red',label_red);

	// console.log('label',label);


	var totalRecords = Object.keys(dataset_blue).length;
	// var ctx = document.getElementById("holt_winter_actual_fitted_line_chart1").getContext('2d');
	  myChart = new Chart(ctx, {
	  type: 'line',
	  plugins: [{
			    afterLayout: chart => {
			      var ctx = chart.chart.ctx;
			      var xAxis = chart.scales['x-axis-0'];
			      var gradientStroke = ctx.createLinearGradient(xAxis.left, 0, xAxis.right, 0);
			      var dataset = chart.data.datasets[0];
			      dataset.colors.forEach((c, i) => {
			        var stop = 1 / (dataset.colors.length - 1) * i;
			        gradientStroke.addColorStop(stop, dataset.colors[i]);
			      });
			      dataset.backgroundColor = gradientStroke;
			      dataset.borderColor = gradientStroke;
			      dataset.pointBorderColor = gradientStroke;
			      dataset.pointBackgroundColor = gradientStroke;
			      dataset.pointHoverBorderColor = gradientStroke;
			      dataset.pointHoverBackgroundColor = gradientStroke;
			    }
	    }],
	  data: {
		   
		    labels: label,
		    datasets: [
		    {
		      label: '#Forecast Line',
		      data: dataset_blue,
		      // backgroundColor: 'rgba(255, 99, 132, 0.2)',
		      // borderColor: 'blue',
		      borderWidth: 2,
		      fill: false,
		       colors: color_array
		    },

		    
		    ]
		  },
		  options: {
		    scales: {
		      yAxes: [{
		        ticks: {
		          beginAtZero: false,
		          // min:3000000,          
		          // stepSize: 100, // this worked as expected
		          // min:1500          
		        }
		      }],
		      xAxes: [{
		        ticks: {
		          maxTicksLimit: (totalRecords/ 12),
		           maxRotation:-120
		          // maxTicksLimit: 5
		        }
		      }]
		    }
		  }
		});


}


function get_month_name(month) {
	const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
	  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	const monthNames1 = ["January", "February", "March", "April", "May", "June",
	  "July", "August", "September", "October", "November", "December"];
	var getMonth_val=monthNames[month];
    return getMonth_val

}
// console.log('sssssssss',get_month_name(12));

});


//document close










